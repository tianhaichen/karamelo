Zlib 1.2.11 already compiled from (downloaded on 2019-05-22):

  https://www.nuget.org/packages/zlib-msvc14-x64/
